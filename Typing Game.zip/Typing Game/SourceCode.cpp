#include<time.h>
#include<conio.h>
#include<stdio.h>
#include<windows.h>
#include<dos.h>
#include<stdlib.h>
#include<bits/stdc++.h>
using namespace std;
static int x=1;
#define pos gotoxy(33,x++) 
#define ln  printf(".......................");
 COORD coord={0,0};
 void gotoxy(int x,int y);
void gotoxy(int x,int y)
{
    coord.X=x;
    coord.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

void delay(unsigned int mseconds)
{
    clock_t goal=mseconds+clock();
    while(goal>clock());
}

void setcolor(int ForgC) 
 {
 WORD wColor;

  HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
  CONSOLE_SCREEN_BUFFER_INFO csbi;

                     
 if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
 {
      wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
      SetConsoleTextAttribute(hStdOut, wColor);
 }
 return;
 }

void sett();
int t=30;
int c=0;

char name[15];
void getscore(int score,int speed,int level);
void practice();
void w_practice();
void s_practice();
void startgame();  
void scorecard();  
void About_me();
void help();
void rectangle(int x,int y,int l,int b)
{
    int i,m;
    gotoxy(x,y); printf("%c",201);
    for(i=x+1;i<l-1;i++)
    {
        gotoxy(i,y);
        printf("%c",205);
    }
    gotoxy(i,y); printf("%c",187);

    for (m=y+1;m<b;m++)
    {
        gotoxy(x,m);
        for(i=x;i<l;i++)
        {
            if(i==x||i==l-1)
            {
                gotoxy(i,m); printf("%c",186);
            }

        }

    }

    gotoxy(x,m); printf("%c",200);
    for(i=x+1;i<l-1;i++)
    {
        gotoxy(i,m);
        printf("%c",205);
    }
    gotoxy(i,m); printf("%c",18);
}
int main()
{       int ch;

	time_t t;
	time(&t);
	x=1;
	system("cls");
	pos;
	setcolor(12) ;
	printf("Welcome to typing game ");
	setcolor(10) ;
	pos;
	printf("%s",ctime(&t));
	pos;
    ln pos;
	if(c==0)
	   {	printf("Enter player's name::");
		gets(name);
	   }
	   c++;
	pos;ln pos;
		printf("#..MAIN MENU..#");pos;
		ln
		pos;
		printf("1.Startgame");
		pos;
		printf("2.Scorecard");
		pos;
		printf("3.Set the time limit::");
		pos;
		printf("4.Practice");
		pos;
		printf("5.Help");
		pos;
		printf("6.About me");
		pos;
		printf("0.Exit");
		pos;
		printf("Enter your choice::");
		scanf("%d",&ch);
		pos;
		switch(ch)
		{   case 1:startgame();break;
			case 2:scorecard();break;
			case 3:sett();main();
			case 4:practice();break;
			case 5:help();break;
			case 6:About_me();break;
			case 0:system("cls");gotoxy(17,10);printf("#This Game is created by Prodip sarker#");delay(1000);exit(1);
			default:main();
		}

getch();
}

void practice()
{
	clock_t begin;
rectangle(0,0,70,15);
	delay(500);
	system("cls");
	srand(time(NULL)) ; 
	x=2;
	pos;
	setcolor(12);
	pos;
	printf("1.Word practice");
	pos;
	printf("2.Sentence practice");
	pos;
	printf("Enter choice:");
	int prc;
	pos;
	scanf("%d",&prc);
	if(prc==1)
	w_practice();
	else if(prc==2)
	s_practice();
	
}
void w_practice()
{
FILE * fp;
        char c;
        string ch;
        int k=0;
        string str;
        fp = fopen("word.txt", "r");
       int score=0,level=1,mode=100,count=0;
	clock_t begin;
	int time_spent,speed;
rectangle(0,0,70,15);
	delay(500);
	system("cls");
	srand(time(NULL)) ; 
	x=2;
	pos;
	setcolor(12);
		begin=clock();
	
	 while ((c = getc(fp)) != EOF)
		{       system("cls");
			time_spent=(int)(clock()-begin)/CLOCKS_PER_SEC;
			if(time_spent>=t)
			break;
			gotoxy(20,8);
			printf("....Type the following word....");
			gotoxy(36,11) ;
			
        	if(c!=' ')
        	ch+=c;
        	if(c==' ')
			{
				cout<<ch;
				delay(2000);
				pos;
				gotoxy(37,11);
				pos;
				gotoxy(37,12);
				cin>>str;
				if(str==ch)
				k++;
				ch="\0";
			} 
		}
		pos;
		cout<<"You have corrected "<<k<<" words\n";
		pos;
		cout<<"1.Play again";
		pos;
		cout<<"2.Main menu";
		pos;
		cout<<"0.Exit";
		pos;
		int n;
		cin>>n;
		if(n==1)
		w_practice();
		else if(n==2)
		main();
		else if(n==0){
			system("cls");
		gotoxy(17,10);
		printf("#This Game is created by Prodip sarker#");
		delay(1000);exit(1);
	}
	
}
void s_practice()
{
	    char ch;
	    string str,str1;
	FILE *fp;
	system("cls");
	x=3;
	char c;
	pos;
	printf("Type the given sentences\n");
	pos;
	ln;
printf("\n");
	fp=fopen("sen1.txt","r");
	while((ch=fgetc(fp))!=EOF)
	{
		printf("%c",ch);
		c=ch;
		str+=c;
	}
	printf("\n\n");
	cin.ignore();
	getline(cin,str1);
	int k=0;
	string ss,ss1;
	stringstream c1(str);
	stringstream c2(str1);
	while(c1>>ss&&c2>>ss1)
	{
		if(ss==ss1)
		++k;
	}
	cout<<"You correct "<<k<<" words.Good Luck!\n\n";
		printf("1.# play again #\n");
		printf("2.# main menu #\n");
		printf("3.exit\n"); 
		printf("Enter your choice::\n");
		scanf("%d",&ch);
		switch(ch)
		{
		      case 1:s_practice();break;
		      case 2:main();break;
		      case 3:system("cls");gotoxy(17,10);printf("#This Game is created by Prodip sarker\n");delay(1000);exit(1);
		      default:pos;printf("wrong choice!");pos;
				main();
		}
	
	getch();
}
void n_practice()
{
	
}
void startgame()
{       int score=0,level=1,mode=100,count=0;
	clock_t begin;
	int time_spent,speed;
	int r,letter,ch;
rectangle(0,0,70,15);
	delay(500);

	system("cls");
	srand(time(NULL)) ; 
	x=2;
	pos;
	setcolor(12);
	printf("#Select the Mode#");pos;
	ln
	pos;
	printf("1.Easy mode#");
	pos;
	printf("2.Normal mode#");
	pos;
	printf("3.Hard mood#");
	pos;
	printf("4.Back to main menu#");
	pos;
	scanf("%d",&level);
	if(level==4)
	main();

	else

	{     if(level==1)    
	       mode=65;
	     if(level==2)    
		mode=97;
	     if(level==3)    
		mode=120;
		begin=clock();
		while(1)
		{       system("cls");
			time_spent=(int)(clock()-begin)/CLOCKS_PER_SEC;

			if(time_spent>=t)
			break;
			r=rand()%1000;
			r=r%26+mode;
			gotoxy(20,8);
			printf("....Type the following character....");
			gotoxy(36,11) ;
			printf(" %c",r); 

			letter=getch();

			if(letter!=r)
			break;
			else
			{       count++;
				score=score+10;
				gotoxy(28,9);
				printf("score=%d",score);
				gotoxy(37,9);
				printf("time_spent=%d sec",time_spent);

				if(level==1)
				delay(400);
				if(level==2)
				delay(200);
				if(level==3)
				delay(100);

			} 
		}
		gotoxy(26,x);

		delay(400);

		setcolor(5);
		++x;
		pos;
		speed=(count*60)/time_spent ;
		if(time_spent<t-1)
		printf("You  are looser!loser!loser!Game Over!");
		else
		{       setcolor(11);
			printf("Times up !Game over!");
			pos;
			setcolor(5);
			if((speed>=40)&&(speed<=50))
			{	printf("Good Work !Keep it up!");pos;

				printf("You got silver medal");
			}
			else
			if(speed>50)
			{
				printf("Nice work! You got Gold medal");
			}
			else
			printf("Sorry no medal !you need practice..");
		}
		pos;
		printf("Total score is ::%d",score);
		pos;

		printf("Your net speed=%d letter per minute",speed);

		getscore(score,speed,level);
		++x;
		pos;
		printf("1.# play again #");
		pos;

		printf("2.# main menu #");pos;
		printf("3.exit"); pos;
		printf("Enter your choice::");
		scanf("%d",&ch);
		switch(ch)
		{
		      case 1:startgame();break;
		      case 2:main();break;
		      case 3:system("cls");gotoxy(17,10);printf("#This Game is created by Prodip sarker#");delay(1000);exit(1);
		      default:pos;printf("wrong choice!");pos;
				main();
		}

	}

}

void sett()  
{
	int ch;
	system("cls");
	setcolor(11);
	x=5;
	pos;
	printf("Set the time limit for game in minute::");
	pos;
	ln
	pos;
	printf("press 0 for half minute") ;pos;
	printf("press 1 for 1 minute"); pos;
	printf("press 2 for 2 minute");pos;
	scanf("%d",&ch);
	switch(ch)
	{
		case 0:t=30;break;
		case 1:t=60;break;
		case 2:t=120;break;
		default:main();
	}
}

void help()
{
	system("cls");
	gotoxy(7,5);
	setcolor(6);

	printf("#......Rules of the Game......#");gotoxy(7,6);
	printf("=>Enter your name as player name");gotoxy(7,7);
	printf("=>Set the time limit under option 3 in main menu(default limit is 30 sec)");gotoxy(7,8);
	printf("=>select the level and get started :");gotoxy(7,9);
	printf("=>Characters are displayed and you have to type them as fast as you can..");gotoxy(7,10);
	printf("=>Avoid incorrect typing otherwise game will be over..");
	getch();main();
}
void About_me()
{       system("cls");
	gotoxy(7,7);
	printf("Hello everyone,This game is made by Prodip sarker Dept. of ICT,MBSTU\n");
       printf(".I think it would be better....thanks...");
       getch();
       main();
}

void getscore(int score,int speed,int level)
{
	FILE *fp;
	fp=fopen("file.txt","a");
	pos;
	if(fp==NULL)
	printf("error in opening file");
	fprintf(fp,"\nname=%s   score=%d    speed=%d    level=%d",name,score,speed,level);
	fclose(fp);
	pos;
	printf("scorecard updated");
}
void scorecard()
{       int ch;
	FILE *fp;
	system("cls");
	x=3;

	printf("\t\t\t....The scores are...\n");

	fp=fopen("file.txt","r");
	while((ch=fgetc(fp))!=EOF)
	{	printf("%c",ch);
	}
	getch();
	main();
}


